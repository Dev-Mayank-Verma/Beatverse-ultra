# BeatVerse

BeatVerse is a free, open-source music player for Android, powered by **Team ScholarVerse**.
Developer: **Mayank Verma**.

## Attribution

BeatVerse is a modified version of [Bloomee Tunes](https://github.com/HemantKArya/BloomeeTunes)
by Hemant K Arya, released under the GNU General Public License v2 (see `LICENSE`).
Original copyright notices are retained as required by the license.
